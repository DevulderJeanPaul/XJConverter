**mx lib** ( v0.8 10.15.2005)

MacOS 10.15+ (Apple silicon M1 to M4)

### What is ?

It's a alternative gui library for PureBasic 

Why ?

She add more controls (map, token, search, token, popover)

More notifications and customisation of standard controls, better menu

Like custom height for Listview, controls in listview



80% of commands  are the same syntax of PureBasic

Change are prefix **mx_** for each command and constants begin by **#MX**

------

**Demo**

Run the program "**bigDemo.pb**"

For see new controls, use the mousewheel fonction in sidebar view

The demo made nothing, just show controls :)

See below mail address for suggestions, bug reports



![scr](/Users/jpaul/Desktop/examples/scr.png)

------

**Version**

2 versions of library :

​	**Standard version** are free for all

​	**Commercial version** ?

​	a commercial may be available if market exist 

​	have support, more controls and access full source code

​	Write at jpaul@swiftpw.com if this version may be cool for you, or write pm in Purebasic (english forum)

​	Price 25€ for two year supports.

------

Thanks,

Contents of directory:

mx.dylib (the gui lib)

MXConstants.pbi (constant of library)

mx.pbi (purebasic wrapper for mx library)

readme.pdf

readme.md

japon.png